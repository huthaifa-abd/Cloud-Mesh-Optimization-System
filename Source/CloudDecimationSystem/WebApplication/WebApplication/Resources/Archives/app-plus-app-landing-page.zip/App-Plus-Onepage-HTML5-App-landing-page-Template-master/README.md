App-Plus is a very clean Landing Page Template for Mobile App. Well organized and very easy to customize, App-Plus is better way to present and promote your startup mobile app website
<a href="http://app-plus.themefisher.com">Live Preview</a>
Preview:-
<img src="https://cloud.githubusercontent.com/assets/10640964/5987673/767dce82-a962-11e4-9859-74630cc59a7d.png" />

